| Path                          | Horizon   | Incremental output response   | Cumulative K_Y   | Incremental spending response   | Cumulative K_G   | K_Y/K_G   |
|:------------------------------|:----------|:------------------------------|:-----------------|:--------------------------------|:-----------------|:----------|
| EU27 panel benchmark          | 0         | +1.140 (0.256)                | 1.140            | +1.000 (0.000)                  | 1.000            | 1.140     |
| EU27 panel benchmark          | 1         | +0.916 (0.315)                | 2.056            | +0.004 (0.088)                  | 1.004            | 2.049     |
| EU27 panel benchmark          | 2         | +0.142 (0.244)                | 2.198            | -0.174 (0.049)                  | 0.829            | 2.650     |
| EU27 panel benchmark          | 3         | -0.257 (0.277)                | 1.941            | -0.131 (0.062)                  | 0.698            | 2.780     |
| EU27 panel benchmark          | 4         | -0.213 (0.324)                | 1.728            | -0.041 (0.060)                  | 0.657            | 2.629     |
| EU27 panel benchmark          | 5         | -0.018 (0.094)                | 1.710            | -0.003 (0.024)                  | 0.654            | 2.614     |
| EU27 panel benchmark          | 6         | +0.066 (0.096)                | 1.776            | -0.007 (0.036)                  | 0.648            | 2.743     |
| EU27 panel benchmark          | 7         | +0.102 (0.163)                | 1.879            | +0.028 (0.051)                  | 0.676            | 2.779     |
| EU27 panel benchmark          | 8         | +0.229 (0.138)                | 2.108            | +0.081 (0.040)                  | 0.757            | 2.786     |
| Household net financial worth | 0         | +1.194 (0.337)                | 1.194            | +1.000 (0.000)                  | 1.000            | 1.194     |
| Household net financial worth | 1         | +1.172 (0.307)                | 2.366            | +0.054 (0.075)                  | 1.054            | 2.244     |
| Household net financial worth | 2         | +0.096 (0.245)                | 2.462            | -0.214 (0.041)                  | 0.841            | 2.929     |
| Household net financial worth | 3         | -0.533 (0.316)                | 1.929            | -0.138 (0.065)                  | 0.702            | 2.746     |
| Household net financial worth | 4         | -0.362 (0.325)                | 1.567            | -0.027 (0.061)                  | 0.676            | 2.319     |
| Household net financial worth | 5         | +0.047 (0.118)                | 1.614            | +0.003 (0.032)                  | 0.678            | 2.379     |
| Household net financial worth | 6         | +0.015 (0.131)                | 1.629            | +0.000 (0.035)                  | 0.678            | 2.402     |
| Household net financial worth | 7         | +0.145 (0.181)                | 1.774            | +0.021 (0.027)                  | 0.700            | 2.535     |
| Household net financial worth | 8         | +0.384 (0.071)                | 2.158            | +0.046 (0.036)                  | 0.746            | 2.893     |
| Investment import content     | 0         | +1.387 (0.215)                | 1.387            | +1.000 (0.000)                  | 1.000            | 1.387     |
| Investment import content     | 1         | +0.918 (0.320)                | 2.306            | +0.015 (0.068)                  | 1.015            | 2.273     |
| Investment import content     | 2         | -0.008 (0.263)                | 2.297            | -0.183 (0.048)                  | 0.831            | 2.763     |
| Investment import content     | 3         | -0.449 (0.312)                | 1.849            | -0.148 (0.070)                  | 0.684            | 2.704     |
| Investment import content     | 4         | -0.418 (0.347)                | 1.430            | -0.073 (0.052)                  | 0.611            | 2.342     |
| Investment import content     | 5         | -0.209 (0.100)                | 1.221            | -0.011 (0.036)                  | 0.600            | 2.037     |
| Investment import content     | 6         | +0.076 (0.160)                | 1.297            | -0.018 (0.035)                  | 0.581            | 2.231     |
| Investment import content     | 7         | +0.198 (0.094)                | 1.496            | +0.037 (0.053)                  | 0.619            | 2.418     |
| Investment import content     | 8         | +0.343 (0.091)                | 1.838            | +0.075 (0.038)                  | 0.694            | 2.649     |
