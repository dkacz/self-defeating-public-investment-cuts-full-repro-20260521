| Specification                 | Outcome                    | Horizon   | Observations   | Countries   | Years     | Design matrix rank   |
|:------------------------------|:---------------------------|:----------|:---------------|:------------|:----------|:---------------------|
| Investment import content     | Output                     | 0         | 531            | 27          | 2004-2023 | 8/8                  |
| Investment import content     | Output                     | 1         | 531            | 27          | 2004-2023 | 8/8                  |
| Investment import content     | Output                     | 2         | 506            | 27          | 2004-2022 | 8/8                  |
| Investment import content     | Output                     | 3         | 481            | 27          | 2004-2021 | 8/8                  |
| Investment import content     | Output                     | 4         | 456            | 27          | 2004-2020 | 8/8                  |
| Investment import content     | Output                     | 5         | 431            | 27          | 2004-2019 | 8/8                  |
| Investment import content     | Output                     | 6         | 405            | 27          | 2004-2018 | 8/8                  |
| Investment import content     | Output                     | 7         | 378            | 27          | 2004-2017 | 8/8                  |
| Investment import content     | Output                     | 8         | 351            | 27          | 2004-2016 | 8/8                  |
| Investment import content     | Public investment spending | 0         | 531            | 27          | 2004-2023 | 8/8                  |
| Investment import content     | Public investment spending | 1         | 531            | 27          | 2004-2023 | 8/8                  |
| Investment import content     | Public investment spending | 2         | 506            | 27          | 2004-2022 | 8/8                  |
| Investment import content     | Public investment spending | 3         | 481            | 27          | 2004-2021 | 8/8                  |
| Investment import content     | Public investment spending | 4         | 456            | 27          | 2004-2020 | 8/8                  |
| Investment import content     | Public investment spending | 5         | 431            | 27          | 2004-2019 | 8/8                  |
| Investment import content     | Public investment spending | 6         | 405            | 27          | 2004-2018 | 8/8                  |
| Investment import content     | Public investment spending | 7         | 378            | 27          | 2004-2017 | 8/8                  |
| Investment import content     | Public investment spending | 8         | 351            | 27          | 2004-2016 | 8/8                  |
| Household balance-sheet fragility | Output                     | 0         | 531            | 27          | 2004-2023 | 8/8                  |
| Household balance-sheet fragility | Output                     | 1         | 531            | 27          | 2004-2023 | 8/8                  |
| Household balance-sheet fragility | Output                     | 2         | 506            | 27          | 2004-2022 | 8/8                  |
| Household balance-sheet fragility | Output                     | 3         | 481            | 27          | 2004-2021 | 8/8                  |
| Household balance-sheet fragility | Output                     | 4         | 456            | 27          | 2004-2020 | 8/8                  |
| Household balance-sheet fragility | Output                     | 5         | 431            | 27          | 2004-2019 | 8/8                  |
| Household balance-sheet fragility | Output                     | 6         | 405            | 27          | 2004-2018 | 8/8                  |
| Household balance-sheet fragility | Output                     | 7         | 378            | 27          | 2004-2017 | 8/8                  |
| Household balance-sheet fragility | Output                     | 8         | 351            | 27          | 2004-2016 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 0         | 531            | 27          | 2004-2023 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 1         | 531            | 27          | 2004-2023 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 2         | 506            | 27          | 2004-2022 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 3         | 481            | 27          | 2004-2021 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 4         | 456            | 27          | 2004-2020 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 5         | 431            | 27          | 2004-2019 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 6         | 405            | 27          | 2004-2018 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 7         | 378            | 27          | 2004-2017 | 8/8                  |
| Household balance-sheet fragility | Public investment spending | 8         | 351            | 27          | 2004-2016 | 8/8                  |
