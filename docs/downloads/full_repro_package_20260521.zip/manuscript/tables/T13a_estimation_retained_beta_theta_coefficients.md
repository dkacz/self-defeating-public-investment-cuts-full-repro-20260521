| Specification                 | Outcome                    | Horizon   | Mean-state coefficient ($\beta_h$)                   | State-interaction coefficient ($\theta_h$)                  | Interacted state variable     |
|:------------------------------|:---------------------------|:----------|:-------------------------|:-------------------------|:------------------------------|
| Investment import content     | Output                     | 0         | +0.051 (0.009; p=<0.001) | -0.036 (0.009; p=<0.001) | investment import content     |
| Investment import content     | Output                     | 1         | +0.036 (0.012; p=0.004)  | -0.011 (0.011; p=0.326)  | investment import content     |
| Investment import content     | Output                     | 2         | +0.001 (0.010; p=0.950)  | +0.006 (0.008; p=0.460)  | investment import content     |
| Investment import content     | Output                     | 3         | -0.017 (0.012; p=0.158)  | +0.007 (0.013; p=0.579)  | investment import content     |
| Investment import content     | Output                     | 4         | -0.016 (0.014; p=0.251)  | +0.009 (0.017; p=0.593)  | investment import content     |
| Investment import content     | Output                     | 5         | -0.006 (0.004; p=0.085)  | +0.014 (0.008; p=0.081)  | investment import content     |
| Investment import content     | Output                     | 6         | +0.002 (0.006; p=0.766)  | -0.009 (0.009; p=0.315)  | investment import content     |
| Investment import content     | Output                     | 7         | +0.005 (0.003; p=0.145)  | -0.021 (0.016; p=0.188)  | investment import content     |
| Investment import content     | Output                     | 8         | +0.012 (0.005; p=0.014)  | -0.018 (0.006; p=0.004)  | investment import content     |
| Investment import content     | Public investment spending | 0         | +0.041 (0.001; p=<0.001) | +0.000 (0.001; p=0.972)  | investment import content     |
| Investment import content     | Public investment spending | 1         | +0.000 (0.003; p=0.940)  | -0.002 (0.003; p=0.361)  | investment import content     |
| Investment import content     | Public investment spending | 2         | -0.008 (0.002; p=<0.001) | -0.001 (0.002; p=0.780)  | investment import content     |
| Investment import content     | Public investment spending | 3         | -0.006 (0.003; p=0.035)  | +0.000 (0.002; p=0.969)  | investment import content     |
| Investment import content     | Public investment spending | 4         | -0.003 (0.002; p=0.230)  | +0.002 (0.002; p=0.369)  | investment import content     |
| Investment import content     | Public investment spending | 5         | -0.000 (0.001; p=0.703)  | -0.000 (0.002; p=0.935)  | investment import content     |
| Investment import content     | Public investment spending | 6         | -0.001 (0.001; p=0.629)  | +0.000 (0.001; p=0.761)  | investment import content     |
| Investment import content     | Public investment spending | 7         | +0.001 (0.002; p=0.520)  | -0.001 (0.001; p=0.295)  | investment import content     |
| Investment import content     | Public investment spending | 8         | +0.003 (0.002; p=0.031)  | +0.001 (0.001; p=0.408)  | investment import content     |
| Household balance-sheet fragility | Output                     | 0         | +0.046 (0.009; p=<0.001) | +0.008 (0.013; p=0.565)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 1         | +0.029 (0.012; p=0.018)  | +0.028 (0.011; p=0.011)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 2         | +0.007 (0.010; p=0.517)  | -0.003 (0.007; p=0.623)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 3         | -0.002 (0.008; p=0.765)  | -0.027 (0.010; p=0.011)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 4         | -0.005 (0.011; p=0.664)  | -0.014 (0.008; p=0.095)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 5         | -0.004 (0.005; p=0.354)  | +0.008 (0.009; p=0.344)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 6         | +0.002 (0.007; p=0.756)  | -0.002 (0.012; p=0.880)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 7         | +0.002 (0.006; p=0.784)  | +0.006 (0.007; p=0.371)  | household balance-sheet fragility |
| Household balance-sheet fragility | Output                     | 8         | +0.004 (0.008; p=0.619)  | +0.017 (0.007; p=0.013)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 0         | +0.040 (0.001; p=<0.001) | +0.004 (0.001; p=<0.001) | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 1         | -0.001 (0.004; p=0.716)  | +0.005 (0.002; p=0.005)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 2         | -0.006 (0.003; p=0.033)  | -0.004 (0.002; p=0.074)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 3         | -0.005 (0.003; p=0.046)  | -0.001 (0.002; p=0.498)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 4         | -0.002 (0.003; p=0.418)  | +0.001 (0.002; p=0.439)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 5         | -0.000 (0.001; p=0.732)  | +0.001 (0.002; p=0.767)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 6         | -0.001 (0.002; p=0.716)  | +0.001 (0.002; p=0.703)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 7         | +0.001 (0.003; p=0.708)  | -0.000 (0.003; p=0.912)  | household balance-sheet fragility |
| Household balance-sheet fragility | Public investment spending | 8         | +0.004 (0.002; p=0.010)  | -0.003 (0.001; p=0.015)  | household balance-sheet fragility |
